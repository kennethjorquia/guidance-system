<?php

    
    define('DBINFO','mysql:host=localhost;dbname=sms_guidance_system');
    define('DBUSER','root');
    define('DBPASS','');

    
    function multi_query($query){
        $con = new PDO(DBINFO,DBUSER,DBPASS);
        $stmt = $con->prepare($query);
        if($stmt->execute()){
            return true;
        }else{
            return false;
        }
    }

    function fetchAll($query){
        $con = new PDO(DBINFO, DBUSER, DBPASS);
        $stmt = $con->query($query);
        return $stmt->fetchAll();
    }

?>