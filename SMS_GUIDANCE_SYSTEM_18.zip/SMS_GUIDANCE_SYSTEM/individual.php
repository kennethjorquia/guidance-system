<?php
include 'includes/sms_db.php';
include 'assets/body/upper.php';
?>
<section class="home-section ms-3 p-3">
  <!--------------------------------------------------------------------------edit here------------------------------------------------------------------------------------------->
  <div class="card p-3 border-0 mb-3 rounded-0  mb-2 shadow">
    <div class="card-body">
      <div class="page-breadcrumb border-bottom border-dark">
                <div class="row align-items-center">
                    <div class="col-5">
                    <div class="d-flex align-items-start">
                      <ion-icon class="me-2" size="large" style="color:#A7727D" name="person-circle-sharp"></ion-icon>
                        <h4 class="text-dark fw-bold">Individual Counseling</h4>
                      </div>
                        <div class="d-flex align-items-center">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Individual Counseling</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>

  <div class="card p-3 border-0 overflow-auto mb-3 mt-3 rounded-0 shadow" style="height:650px;">
  <div class="card-body"> 
  <div class="py-3">
  <a class="btn btn-success" href="pages/services/indv_counseling.php" role="button"><ion-icon class="me-1" name="create-sharp"></ion-icon>Start Counseling</a>
  </div>
  <div class="d-flex justify-content-between align-items-center">
    <div class="dropdown d-flex align-items-center">

      <button class="btn text-black me-3  dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"> Behavior Therapy </button>
      <button href="index.php" type="button" class="btn btn-primary text-light">Filter</button>
      <ul class="dropdown-menu">
        <li><a class="dropdown-item" href="#">Behavior Therapy</a></li>
        <li><a class="dropdown-item" href="#">Cognitive Therapy</a></li>
        <li><a class="dropdown-item" href="#">Educational Counseling</a></li>
        <li><a class="dropdown-item" href="#">Holistic Therapy</a></li>
        <li><a class="dropdown-item" href="#">Mental Health Counseling</a></li>
      </ul>
    </div>
  
  </div>

  <table id="individual" class="table table-striped table-bordered">
    <thead>
      <tr>
        <th scope="col">ID</th>
        <th scope="col">Student Number</th>
        <th scope="col">Student Name</th>
        <th scope="col">Counseling Type</th>
        <th scope="col">status</th>
        <th scope="col">Approach</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>
    <?Php
    $query="SELECT * FROM guidance_individual";
    if($stmt=$conn->query($query)){
      while ($row=$stmt->fetch_array()) {
      echo "
      <tr>
        <td>$row[indv_id]</td>
        <td>$row[stud_id]</td>
        <td>$row[name]</td>
        <td>$row[course_year_section]</td>
        <td>$row[status]</td>
        <td>$row[approach]</td>
        <td>
          <a class='btn btn-primary' type='button' href='pages/services/view_indv.php?indv_id=$row[indv_id]'><ion-icon class='me-1' name='eye-sharp'></ion-icon>View</a>
        </td>
      </tr>";
      }

    }
    ?>
    </tbody>
  </table>
  </div>
</div>
  <!--------------------------------------------------------------------------edit here------------------------------------------------------------------------------------------->
</section>

  <!--View Result -->
<div class="modal fade" id="view" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Counseling Result</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="view_individual" method="post">
        <input type="hidden" name="id">
      <div class="row">
        <label for="staticEmail" class="col-sm-2 col-form-label" >Student Num#:</label>
          <div class="col-sm-10">
            <input type="text" readonly class="form-control-plaintext" name="stud_id" value="">
          </div>
      </div>
      <div class="row">
        <label for="staticEmail" class="col-sm-2 col-form-label" >Student Name:</label>
          <div class="col-sm-10">
            <input type="text" readonly class="form-control-plaintext" name="name" value="">
          </div>
      </div>
      <div class="row">
        <label for="staticEmail" class="col-sm-3 col-form-label" >Course/Year/Section:</label>
          <div class="col-sm-9">
            <input type="text" readonly class="form-control-plaintext" name="course_year_section" value="">
          </div>
      </div>
      <div class="row">
        <label for="staticEmail" class="col-sm-2 col-form-label" >Status:</label>
          <div class="col-sm-10">
            <input type="text" readonly class="form-control-plaintext" name="status" value="">
          </div>
      </div>
          </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>

  <?php
  include 'assets/body/lower.php';
?>

<script>  
 $(document).ready(function(){  
      $('#individual').DataTable();  
 });  
 </script>  

